Punctaj rulare locala: 100/100p + 6/20 valgrind

Bazele programului:

- implementarea simularii unui tren cu numar infinit de vagoane, 
o locomotiva si un mecanic asupra careia se pot efectua mai multe comenzi

A. Comenzi implementate: (exista doua tiputi de comezni)

1) Comenzi directe (se executa pe loc)
    - SHOW = afisarea trenului complet
    - MOVE_LEFT = muta mecanicul o pozitie la stanga (daca e posibil)
    - MOVE_RIGHT = muta mecanicul o pozitie la dreapta
    - WRITE = schimba valoarea vagonului in care sta mecanicul
    - CLEAR_CELL = elimina vagonul mecanicului
    - CLEAR_ALL = readuce trenul in starea initiala
    - INSERT_LEFT = adauga un vagon in tren la stanga mecanicului
    - INSERT_RIGHT = adauga un vagon in tren la dreapta mecanicului
    - SHOW_CURRENT = afiseaza valoarea vagonului in care sta mecanicul
    - SWITCH = inverseaza ordinea comenzilor in coada
    - SEARCH = cauta un string in tot trenul
    - SEARCH_LEFT = cauta un string in stanga mecnaicului
    - SEARCH_RIGHT = cauta un string la dreapta mecanicului
    - EXECUTE = executa comanda aflata la varful cozii

2) Comenzi indirecte (se adauga intr-o coada de unde vor fi executate cand
va veni randul lor)

B. Alte functii necesare:

- initTrain = initializarea trenului in formatul locomotiva-vagon(cu valoare
'#')
- initQueue = initializeaza coada cu prima ei comanda
- addCommand = adauga o comanda in coada de comenzi indirecte
- printQueue = functie care afiseaza coada
- createWagon = creaza un vagon pentru tren, initializandu-l cu o valoare data
- addinitWagon = adauga un vagon cu valoarea '#' trenului
- removewagon = elimina un vagon
- removeElement = elimina o comanda din coada dupa ce a fost executata
- freeTrain = elibereaza memoria din tren la finalul programului
- freeQueue = elibereaza memoria din coada la finalul programului