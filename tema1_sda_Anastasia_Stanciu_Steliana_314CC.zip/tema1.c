#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "functions.h"

int main() {
    // initializare tren
    FILE *fp_in = fopen("tema1.in", "r");
    FILE *fp_out = fopen("tema1.out", "w");
    Train train = initTrain();
    Queue queue;
    int nr_com, i;
    char comanda[100], execute[20] = "EXECUTE";
    char show[10] = "SHOW", sh_cr[15] = "SHOW_CURRENT", swch[10] = "SWITCH";
    fscanf(fp_in, "%d", &nr_com);
    // citim linia goala ramasa in datele de intrare
    fgets(comanda, 30, fp_in);
    // // initializarea cozii cu prima comanda
    fgets(comanda, 30, fp_in);
    //eliminam '\n' din numele comenzii
    comanda[strlen(comanda) - 1] = '\0';
    queue = initQueue(comanda);
    --nr_com;
    // citirea comenzilor
    for (i = 0; i < nr_com; i++) {
        fgets(comanda, 30, fp_in);
        // executarea directa a comenzilor de tip query
        comanda[strlen(comanda) - 1] = '\0';
        if (strcmp(execute, comanda) == 0) {
            queue = EXECUTE(queue, &train, fp_out);
        } else if (strcmp(show, comanda) == 0) {
            SHOW(train, fp_out);
        } else if (strcmp(sh_cr, comanda) == 0) {
            SHOW_CURRENT(train, fp_out);
        } else if (strcmp(swch, comanda) == 0) {
            queue = SWITCH(queue);
        } else {
            // adaugarea comenzilor cu executie indirecta in coada
            queue = addCommand(queue, comanda);
        }
    }
    freeTrain(&train);
    free(train);
    freeQueue(&queue);
    free(queue);
    fclose(fp_in);
    fclose(fp_out);
    return 0;
}