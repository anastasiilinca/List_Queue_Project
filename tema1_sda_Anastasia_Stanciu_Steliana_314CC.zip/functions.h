// struct pt un Wagon din lista trenului
typedef struct Wagon {
    char data;
    struct Wagon *next, *prev;
} *Wagon;

// struct tren
typedef struct train {
    Wagon head;
    Wagon mecanic;
    int nr_vagoane;
}*Train;

// struct pt o comanda (celula) din coada de comenzi
typedef struct command {
    char data[30];
    struct command *next;
    struct command *prev;
}*Command;

// struct coada comenzi
typedef struct queue {
    Command head, tail;
    int size;
} *Queue;

Train initTrain();
void SHOW (Train train, FILE *fp_out);
Queue addCommand (Queue queue, char *data);
Queue initQueue (char *data);
void printQueue (Queue queue, FILE *fp_out);
Wagon createWagon (char data);
Train addinitwagon (Train train);
Train removewagon (Train train);
Train MOVE_LEFT (Train train);
Train MOVE_RIGHT (Train train);
Train WRITE (Train train, char C);
Train CLEAR_CELL (Train train);
Train CLEAR_ALL (Train train);
Train INSERT_LEFT (Train train, char data, FILE *fp_out);
Train INSERT_RIGHT (Train train, char data);
void SHOW_CURRENT (Train train, FILE *fp_out);
Queue SWITCH (Queue queue);
Train SEARCH_RIGHT (Train train, char *search, FILE *fp_out);
Train SEARCH_LEFT (Train train, char *search, FILE *fp_out);
Train SEARCH (Train train, char *search, FILE *fp_out);
Queue EXECUTE (Queue queue, Train *train, FILE *fp_out);
void freeTrain (Train *train);
void freeQueue (Queue *queue);