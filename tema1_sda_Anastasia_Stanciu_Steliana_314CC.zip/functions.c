#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "functions.h"

// setarea trenului in starea initiala
Train initTrain () {
    Train train = (Train)malloc(sizeof(struct train));
    train->head = (Wagon)malloc(sizeof(struct Wagon));
    Wagon new = (Wagon)malloc(sizeof(struct Wagon));
    // leg primul nod la santinela
    new->next = train->head;
    // il marchex u '#' (formatul trenului initial)
    new->data = '#';
    new->prev = train->head;
    train->head->next = new;
    train->head->prev = new;
    // mut mecanicul in noul nod
    train->mecanic = new;
    train->nr_vagoane = 1;
    return train;
}

// prinatrea vagoanelor din tren
void SHOW (Train train, FILE *fp_out) {
    Wagon iter = train->head->next;
    int i;
    for (i = 1; i <= train->nr_vagoane; i++) {
        // print vagon in care se afla mecanicul
        if (iter == train->mecanic) {
            fprintf(fp_out, "|%c|", iter->data);
        } else {
            fprintf(fp_out, "%c", iter->data);
        }
        iter = iter->next;
    }
    fprintf(fp_out, "\n");
}

// adaugarea unei comenzi in coada
Queue addCommand (Queue queue, char *data) {
    if (queue->size == 0) {
        freeQueue(&queue);
        free(queue);
        queue = initQueue(data);
        return queue;
    } else {
        Command new = (Command)malloc(sizeof(struct command));
        strcpy(new->data, data);
        // leg noul nod la coada
        new->next = queue->head;
        new->prev = queue->tail;
        queue->tail->next = new;
        queue->head->prev = new;
        // mut pointerul de final la noul nod
        queue->tail = new;
        // cresc numarul de noduri din coada
        queue->size++;
        return queue;
    }
}

// creeaza orimul nod intr-o lista goala
Queue initQueue (char *data) {
    Queue queue = (Queue)malloc(sizeof(struct queue));
    queue->head = (Command)malloc(sizeof(struct command));
    // leg inceputul si sfarsitul cozii la primul nod
    queue->tail = queue->head;
    strcpy(queue->head->data, data);
    queue->head->next = NULL;
    queue->head->prev = NULL;
    // setez numarul de comenzi la 1
    queue->size = 1;
    return queue;
}

// functie pt afisarea comenzilor din coada
void printQueue (Queue queue, FILE *fp_out) {
    Command iter = queue->head;
    int i;
    for(i = 0; i < queue->size; i++) {
        fprintf(fp_out, "%s\n", iter->data);
        iter = iter->next;
    }
}

// functie pt crearea unui vagon
Wagon createWagon (char data) {
    Wagon new = (Wagon)malloc(sizeof(struct Wagon));
    // setez valoarea nodului
    new->data = data;
    // il leg la NULL in ambele directii
    new->next = NULL;
    new->prev = NULL;
    return new;
}

// adaugarea unui vagon cu forma initiala
Train addinitwagon (Train train) {
    Wagon new = (Wagon)malloc(sizeof(struct Wagon));
    new->data = '#';
    Wagon last = train->head->prev;
    // leg noul vagon de santinela (pt circularitate)
    new->next = train->head;
    train->head->prev = new;
    // leg noul nod de ultimul vagon
    new->prev = last;
    last->next = new;
    // mut mecanicul in noul nod creat
    train->mecanic = train->mecanic->next;
    // cresc nr de vagoane
    train->nr_vagoane++;
    return train;
}

// eliminarea unui vagon
Train removewagon (Train train) {
    Wagon tmp = train->mecanic;
    // salvez in before penultimul vagon
    Wagon before = train->mecanic->prev;
    Wagon after = train->mecanic->next;
    // mut mecanicul un vagon in fata celui pe care il sterg
    // sau, in cazul in care mecanicul se afla in orimul vagon
    // il mut la finalul trenului
    if (train->mecanic == train->head->next) {
        train->mecanic = train->head->prev;
    } else {
        train->mecanic = train->mecanic->prev;
    }
    // sterg vagonul in care statea mecanicul
    after->prev = before;
    before->next = after;
    train->nr_vagoane--;
    free(tmp);
    return train;
}

Train MOVE_LEFT (Train train) {
    // daca mecanicul se afla in primul Wagon
    // il mutam in ultimul Wagon
    if (train->mecanic == train->head->next) {
        train->mecanic = train->head->prev;
    } else {
        // altfel doar il mut in bagonul aflat la stanga lui
        train->mecanic = train->mecanic->prev;
    }
    return train;
}

Train MOVE_RIGHT (Train train) {
    // daca mecanicul se afla in ultimul vagon
    // mai creez un vagon la dreapta si il mut acolo
    if (train->mecanic == train->head->prev) {
        train = addinitwagon(train);
    } else {
        // altfel doar execut o simpla mutare la dreapta
        train->mecanic = train->mecanic->next;
    }
    return train;
}

// functie pentru inscriptionarea unui vagon
Train WRITE (Train train, char C) {
    train->mecanic->data = C;
    return train;
}

// functie pentru stergerea unui vagon
Train CLEAR_CELL (Train train) {
    // daca stergem singurul Wagon al trenului
    if (train->nr_vagoane == 1) {
        // il aducem la starea initiala
        train = initTrain();
    } else {
        // altfel doar executam o simpla stergere de vagon
        train = removewagon(train);
    }
    return train;
}

// functie care aduce trenul la starea initiala
Train CLEAR_ALL (Train train) {
    freeTrain(&train);
    free(train);
    train = initTrain();
    return train;
}

Train INSERT_LEFT (Train train, char data, FILE *fp_out) {
    // daca mecanicul se afla in primul vagon
    // returnez eroare
    if(train->mecanic == train->head->next) {
        fprintf(fp_out, "ERROR\n");
        return train;
    } else {
        // altfel creez un nou nod
        Wagon new = createWagon(data);
        Wagon before = train->mecanic->prev;
        // si il leg la stanga mecaniuclui
        new->next = train->mecanic;
        new->prev = before;
        before->next = new;
        train->mecanic->prev = new;
        train->mecanic = new;
        // incremenez nr de vagoane
        train->nr_vagoane++;
        return train;
    }
}

Train INSERT_RIGHT (Train train, char data) {
    // creez un nou vagon
    Wagon new = createWagon(data);
    Wagon after = train->mecanic->next;
    // il leg la nodul din dreapta
    new->next = after;
    after->prev = new;
    // il leg la mecanic
    new->prev = train->mecanic;
    train->mecanic->next = new;
    // mut mecanicul
    train->mecanic = new;
    train->nr_vagoane++;
    return train;
}

// afiseaza caracterul din vagonul mecanicului
void SHOW_CURRENT (Train train, FILE *fp_out) {
    fprintf(fp_out, "%c\n", train->mecanic->data);
}

Queue SWITCH (Queue queue) {
    char aux[100][100];
    int i;
    Command iter = queue->head;
    // pun toate comenzile din coada intr-o matrice de caractere
    for (i = 0; i < queue->size; i++) {
        strcpy(aux[i], iter->data);
        iter = iter->next;
    }
    // pornesc de la finalul cozii spre inceput si schimb
    // valorile cu cele din matrice
    iter = queue->tail;
    for (i = 0; i < queue->size; i++) {
        strcpy(iter->data, aux[i]);
        // trec la nodul precedent din coada
        iter = iter->prev;
    }
    return queue;
}

Train SEARCH_RIGHT (Train train, char *search, FILE *fp_out) {
    char text[100];
    Wagon iter = train->mecanic;
    int i = 0;
    // cat timp nu ajung la head, scriu caracterele
    // vagoanelor in stringul 'text'
    do {
        text[i] = iter->data;
        ++i;
        // trecem la urmatorul nod
        iter = iter->next;
    } while (iter != train->head);
    // adaugam terminator de sir pt a putea folosi 
    // functiile din string.h
    text[i] = '\0';
    // caut cuvantul cautat
    char *find = strstr(text, search);
    // daca nu l-am gasit returnez eroare
    if (find == NULL) {
        fprintf(fp_out, "ERROR\n");
        return train;
    } else {
        // nr_skip_wag stocheaza nr de vagoane pe care trebuie
        // sa le sara mecanicul pentru a ajunge la finalul 
        // cuvantului in cazul in care cuvantul exista
        int nr_skip_wag = find - text + strlen(search) - 1;
        // mut mecanicul
        for (i = 0; i < nr_skip_wag; i++) {
            train->mecanic = train->mecanic->next;
        }
        return train;
    }
}

Train SEARCH_LEFT (Train train, char *search, FILE *fp_out) {
    char *text = (char*)malloc(sizeof(char) * (train->nr_vagoane + 2));
    int i = 0;
    Wagon iter = train->mecanic;
    // cat timp nu ajung la head, scriu caracterele
    // vagoanelor in stringul 'text'
    while (iter != train->head) {
        text[i] = iter->data;
        ++i;
        iter = iter->prev;
    }
    // adaugam terminator de sir pt a putea folosi 
    // functiile din string.h
    text[i] = '\0';
    // caut elementul cautat
    char *find = strstr(text, search);
    if (find == NULL) {
        fprintf(fp_out, "ERROR\n");
        free(text);
        return train;
    } else {
        // nr_skip_wag stocheaza nr de vagoane pe care trebuie
        // sa le sara mecanicul pentru a ajunge la finalul 
        // cuvantului in cazul in care cuvantul exista
        int nr_skip_wag = find - text + strlen(search) - 1;
        for (i = 0; i < nr_skip_wag; i++) {
            train->mecanic = train->mecanic->prev; 
        }
    }
    free(text);
    return train;
}

Train SEARCH (Train train, char *search, FILE *fp_out) {
    Wagon iter = train->mecanic; 
    // ok marcheaza daca am trecut de head cu cautarea
    int i = 0, ok = 0, j = 0;
    char *text = (char*)malloc(sizeof(char) * (train->nr_vagoane + 2));
    // string in care memorez a doua parte a stringului text, cea pana la finalul trenului
    // inainte sa ne intoarcem cu iteratia din cadrul cautarii la santinela
    // creez acest string a.i. sa mi pot da seama daca elementul cautat se afla 
    // complet la inceputul trenului; daca *search se va afla si in text si in 
    // end_of_train, inseamna ca trebuie sa sarim un vagon in plus(anume santinela)
    // atunci cand mutam mecanicul la inceputului cuvantului cautat 
    char end_of_train[100];
    do {    
        text[i] = iter->data;
        ++i;
        // daca ok = 1 => am trecut de head cu cautarea =>
        // punem caracterele si in 'text' si in 'end of train'
        if(ok == 1) {
            end_of_train[j] = iter->data;
            ++j;
        }
        // daca am ajuns la ultimul vagon
        if (iter == train->head->prev) {
            // sarim peste santinela
            iter = train->head->next;
            ok = 1;
        } else {
            // altfel sarim la urm vagon
            iter = iter->next;
        }
    } while (iter != train->mecanic);
    // punem terminator de sir
    text[i] = '\0';
    // cautam elementul cautat
    char *find = strstr(text, search);
    if (find == NULL) {
        fprintf(fp_out, "ERROR\n");
        free(text);
        return train;
    } else {
        // nr vagoanelor skip depinde de pozitia elementului cautat
        // daca acesta se afla exclusiv la inceputul
        // trenului, atunci trebuie sa sarim si peste santinela pt a muta
        // mecanicul (deci un skip in plus fata de cazul general)
        int nr_skip_wag;
        if (strstr(end_of_train, search) != NULL) {
            nr_skip_wag = find - text + 1;
        } else {
            nr_skip_wag = find - text;
        }
        // mutam mecanicul
        for (i = 0; i < nr_skip_wag; i++) {
            train->mecanic = train->mecanic->next;
        }
        free(text);
        return train;
    }
}

// elimina 1 element din coada
Queue removeElement (Queue queue) {
    // tmp stocheaza nodul care trebuie sters
    Command tmp;
    tmp = queue->head;
    // schimbam head-ul
    queue->head = queue->head->next;
    // scadem nr de comenzi din coada
    queue->size--;
    // sterg nodul
    free(tmp);
    return queue;
}

Queue EXECUTE (Queue queue, Train *train, FILE *fp_out) {
    char *to_execute = (char*)malloc(sizeof(char) * (strlen(queue->head->data) + 2));
    // punem in to_execute prima comanda din coada
    strcpy(to_execute, queue->head->data);
    to_execute[strlen(queue->head->data)] = '\0';
    // am creat string-uri cu numele comenzilor pt a 
    // putea verifica ce comanda am primit
    char mv_lft[20] = "MOVE_LEFT", mv_rgt[20] = "MOVE_RIGHT", write[20] = "WRITE";
    char clr_all[20] = "CLEAR_ALL", clr_cell[20] = "CLEAR_CELL", ins_lft[20] = "INSERT_LEFT";
    char ins_rgt[20] = "INSERT_RIGHT", search[20] = "SEARCH", sr_lft[20] = "SEARCH_LEFT", sr_rgt[20] = "SEARCH_RIGHT";
    // in functie de comanda primita, apelam functia aferenta
    // !! la functiile care au si argument folosim strncmp
    // pentru a nu citi si argumentul
    // de asemenea, o sa citesc argumentul de la adresa stringului 
    // to_execute + nr de caractere din care este alcatuita comanda de baza + 1 
    // (din cauza spatiului dintre comanda si argument)
    if (strcmp(mv_lft, to_execute) == 0) {
        *train = MOVE_LEFT(*train);
    } else if (strcmp(mv_rgt, to_execute) == 0) {
        *train = MOVE_RIGHT(*train);
    } else if (strncmp(write, to_execute, 5) == 0) {
        char C = to_execute[6];
        *train = WRITE(*train, C);
    } else if (strcmp(clr_all, to_execute) == 0) {
        *train = CLEAR_ALL(*train);
    } else if (strcmp(clr_cell, to_execute) == 0) {
        *train = CLEAR_CELL(*train);
    } else if (strncmp(ins_lft, to_execute, 11) == 0) {
        char C = to_execute[12];
        *train = INSERT_LEFT(*train, C, fp_out);
    } else if (strncmp(ins_rgt, to_execute, 12) == 0) {
        char C = to_execute[13];
        *train = INSERT_RIGHT(*train, C);
    // la functiile de search, luam separat key-word-ul care trebuie
    // cautat si il punem intr-un string cu tot cu terminator de sir
    } else if (strncmp(to_execute, sr_lft, 10) == 0) {
        char *key = (char*)malloc(sizeof(char) * (strlen(to_execute + 12) + 2));
        strcpy(key, to_execute + 12);
        *train = SEARCH_LEFT(*train, key, fp_out);
        free(key);
    } else if (strncmp(sr_rgt, to_execute, 12) == 0) {
        char *key = (char*)malloc(sizeof(char) * (strlen(to_execute + 13) + 2));
        strcpy(key, to_execute + 13);
        *train = SEARCH_RIGHT(*train, key, fp_out);
        free(key);
    } else if (strncmp(search, to_execute, 6) == 0) {
        char *key = (char*)malloc(sizeof(char) * (strlen(to_execute + 7) + 1));
        strcpy(key, to_execute + 7);
        *train = SEARCH(*train, key, fp_out);
        free(key);
    }
    // sterg comanda pe care tocmai am executat o din coada
    queue = removeElement(queue);
    free(to_execute);
    return queue;
}

// elibereaza memoria ocupata de tren
void freeTrain (Train *train) {
    Wagon iter = (*train)->head->next;
    for (iter = (*train)->head->next; iter->next != (*train)->head;) {
        Wagon tmp;
        tmp = iter;
        iter = iter->next;
        free(tmp);
    }
    free(iter);
    free((*train)->head);
}

// elibereaza memoria ocupata de coada
void freeQueue (Queue *queue) {
    Command iter = (*queue)->head;
    int i;
    for (i = 1; i <= (*queue)->size; i++) {
        Command tmp = iter;
        iter = iter->next;
        free(tmp);
    }
}